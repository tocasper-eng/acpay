var status_d
function DataForm2_onLoad(row)
{
    status_d=$("#DataForm2").form('status')
}

function DataForm2_onApply()
{
     if(status_d=="updated")
    {
        $("#DataForm2_chjernou").val(rwd_chjernoi())
    }
	return true;
}
