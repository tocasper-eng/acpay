var status_h
var status_d
//01 檔頭編輯狀態
function dfMaster_onLoad(row)
{
    if(row.chjernoz.substring(0,1)=='Y' || row.chjernov.substring(0,1)=='Y')
    {
        const myInput = document.getElementById("dfMaster");
        const allInputs = myInput.querySelectorAll('input, select, textarea');
        allInputs.forEach((element, index) => {
            console.log(index, element.textContent);
            element.disabled = true
        });
    }
    status_h=$("#dfMaster").form('status')
}
//01 檔身編輯狀態
function dfDetail_onLoad(row)
{
    status_d=$("#dfDetail").form('status')
}
//02 檔頭存檔前
function dfMaster_onApply()
{
    if(status_h=="updated")
    {
        $("#DataPanel2_chjernou").val(rwd_chjernoi())
    }
    //筆數回寫檔頭
    // var rows = $('#dgDetail').datagrid('getRows'); 
    //$("#dfMaster_qtcnt").val(rows.length)
    return true;
}
//02 檔身存檔前
function dfDetail_onApply()
{
    if(status_d=="updated")
    {
        $("#dfDetail_chjernou").val(rwd_chjernoi())
    }
    return true;
}
//03 存檔後
function dfMaster_onApplied(data)
{
    rwd_reload()
}
function dfDetail_onApplied(data)
{
    // rwd_reload()
}
//04 過帳狀態旗標顏色 
function dgMaster_chjernop_formatter(value, row, index)
{
    return rwd_color_chjernop(value);
}
//05 核准狀態旗標顏色 
function dgMaster_chjernoz_formatter(value, row, index)
{
    return rwd_color_chjernoz(value);
}
//06 作廢狀態旗標顏色 
function dgMaster_chjernov_formatter(value, row, index)
{
    return rwd_color_chjernov(value);
}
//07 過帳
function ep_post()
{
    var sIndex = $("#dgMaster").datagrid("getSelectedIndex");
    if (sIndex >= 0) {
        rwd_post($("#dgMaster").datagrid("getRows")[sIndex].menuflag,$("#dgMaster").datagrid("getRows")[sIndex].chjernop) 
    }
    else {
        $.alert('請選擇一筆資料','info');
    }
}
//08 核准 
//function ep_codezy()
//{
//    var sIndex = $("#dgMaster").datagrid("getSelectedIndex");
//    if (sIndex >= 0) {
//        rwd_codezy($("#dgMaster").datagrid("getRows")[sIndex].menuflag,$("#dgMaster").datagrid("getRows")[sIndex].chjernoz) 
//    }
//    else {
//        $.alert('請選擇一筆資料','info');
//    }
//}
function ep_codezy() {
    try {
        // 获取数据表格中选中的行
        const selectedRow = $("#dgMaster").datagrid("getSelected");
        // 检查是否选中了数据
        if (!selectedRow) {
            $.alert('請選擇一筆資料', 'info');
            return false;
        }
        // 检查是否已经核准（检查 chjernoz 字段的第一个字符是否为 'Y'）
        if (selectedRow.chjernoz && selectedRow.chjernoz.toString().charAt(0).toUpperCase() === 'Y') {
            $.alert('已經核准，無需核准！', 'info');
            return false;
        }
        // 检查是否已经作废（检查 chjernov 字段的第一个字符是否为 'Y'）
        if (selectedRow.chjernov && selectedRow.chjernov.toString().charAt(0).toUpperCase() === 'Y') {
            $.alert('已經作廢，無需核准！', 'info');
            return false;
        }
        // 所有验证通过，可以执行核准操作
        // 这里可以添加核准的具体逻辑
        rwd_codezy(selectedRow.menuflag, selectedRow.chjernoz);
        return true;
    } catch (error) {
        // 错误处理
        console.error('Error in ep_codezy:', error);
        $.alert('處理資料時發生錯誤', 'error');
        return false;
    }
}
//09 取消
function ep_codezn()
{
    var sIndex = $("#dgMaster").datagrid("getSelectedIndex");
    if (sIndex >= 0) {
        rwd_codezn($("#dgMaster").datagrid("getRows")[sIndex].menuflag,$("#dgMaster").datagrid("getRows")[sIndex].chjernoz) 
    }
    else {
        $.alert('請選擇一筆資料','info');
    }
}
//結案
function ep_closey() {
    var rows = $("#dgMaster").datagrid('getChecked');  //取出所有被勾選的資料
    if (rows.length==0) 
    {
        $.alert('請選擇要結案的資料','info');
        return
    }
    $.loading($('#dgMaster').closest('div'), '處理中...');  // 顯示進度訊息
    for(var i = 0 ;i <rows.length;i++){
        rwd_closey(rows[i].menuflag) 
    }
    $.loaded($('#dgMaster').closest('div')) //關閉訊息框
    $.alert('作業完成','info');
    rwd_reload()
}
//09 取消結案
function ep_closen()
{
    var rows = $("#dgMaster").datagrid('getChecked');  //取出所有被勾選的資料
    if (rows.length==0) 
    {
        $.alert('請選擇要結案的資料','info');
        return
    }
    $.loading($('#dgMaster').closest('div'), '處理中...');  // 顯示進度訊息
    for(var i = 0 ;i <rows.length;i++){
        rwd_closen(rows[i].menuflag) 
    }
    $.loaded($('#dgMaster').closest('div')) //關閉訊息框
    $.alert('作業完成','info');
    rwd_reload()
}
//10 作廢
function ep_void() {
    try {
        const selectedRow = $("#dgMaster").datagrid("getSelected");
        if (!selectedRow) {
            $.alert('請選擇一筆資料', 'info');
            return false;
        }
        // Check if already voided - using first character
        if (selectedRow.chjernov && selectedRow.chjernov.toString().charAt(0).toUpperCase() === 'Y') {
            $.alert('已作廢，不必再作廢！', 'info');
            return false;
        }
        // Check if approved - using first character
        if (selectedRow.chjernoz && selectedRow.chjernoz.toString().charAt(0).toUpperCase() === 'Y') {
            $.alert('已核准，請先取消核准，才能作廢！', 'info');
            return false;
        }
        // If all validations pass, proceed with void operation
        rwd_void(selectedRow.menuflag, selectedRow.chjernov, selectedRow.chjernoz);
        return true;
    } catch (error) {
        console.error('Error in ep_void:', error);
        $.alert('處理資料時發生錯誤', 'error');
        return false;
    }
}
//function ep_void()
//{
//   if (chjernov=="Y")
//   { $.altert('已作廢，不必再作廢！','info')
//  return
//  }
//  if(chjernoiz=="Y")
//  {
//      $.alter('已核准，請先取消核准，才能作廢！','info')
//      return
//  }
//}
//11 核後與廢後不可刪除
function dgMaster_onDelete(row)
{
    if(!chkcode(row.chjernov,'作廢後不可刪除！')) return false 
    if(!chkcode(row.chjernoz,'核准後不可刪除！')) return false 
    return true;
}
//12 核後與廢後不可修改
function dgMaster_onUpdate(row)
{
    return true;
}
//13批次新增
//function openMove()
//{
//  $('#dgDetail').clientmove('openMove');
//}
function DataPanel3_客服類別_onSelect(value)
{
    if(value!='1/ 契約客戶')
        $("#DataPanel1_契約編號").attr('disabled','disabled')
        else
            $("#DataPanel1_契約編號").removeAttr('disabled')
            }
var status_d2
function DataForm2_onLoad(row)
{
    status_d2=$("#DataForm2").form('status')
}
function DataForm2_onApply()
{
    if(status_d2=="updated")
    {
        $("#DataForm2_chjernou").val(rwd_chjernoi())
    }
    return true;
}
var status_d1
function DataForm1_onLoad(row)
{
    status_d1=$("#DataForm1").form('status')
}
function DataForm1_onApply()
{
    if(status_d1=="updated")
    {
        $("#DataForm1_chjernou").val(rwd_chjernoi())
    }
    return true;
}
function dgDetail_onInsert(row)
{
    var chjernoz=$("#DataPanel3_chjernoz").val()
    var chjernov=$("#DataPanel3_chjernov").val()
    if(!chkcode(chjernov,'作廢後不可新增！')) return false 
    if(!chkcode(chjernoz,'核准後不可新增！')) return false 
    return true;
}
function DataGrid1_onInsert(row)
{
    var chjernoz=$("#DataPanel3_chjernoz").val()
    var chjernov=$("#DataPanel3_chjernov").val()
    if(!chkcode(chjernov,'作廢後不可新增！')) return false 
    if(!chkcode(chjernoz,'核准後不可新增！')) return false 
    return true;
}
function dgDetail_onUpdate(row)
{
    var chjernoz=$("#DataPanel3_chjernoz").val()
    var chjernov=$("#DataPanel3_chjernov").val()
    if(!chkcode(chjernov,'作廢後不可修改！')) return false 
    if(!chkcode(chjernoz,'核准後不可修改！')) return false 
    return true;
}
function DataGrid1_onUpdate(row)
{
    var chjernoz=$("#DataPanel3_chjernoz").val()
    var chjernov=$("#DataPanel3_chjernov").val()
    if(!chkcode(chjernov,'作廢後不可修改！')) return false 
    if(!chkcode(chjernoz,'核准後不可修改！')) return false 
    return true;
}
