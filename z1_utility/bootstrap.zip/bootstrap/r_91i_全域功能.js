var status_h
function dfMaster_onLoad(row)
{
    status_h=$("#dfMaster").form('status')
}
function dfMaster_onApply()
{
    if(status_h=="updated")
    {
        $("#dfMaster_chjernou").val(rwd_chjernoi())
    }
    return true;
}

//01 檔身編輯狀態
function dfDetail_onLoad(row)
{
   status_d=$("#dfDetail").form('status')
}

//02 檔身存檔前
function dfDetail_onApply()
{
    if(status_d=="updated")
    {
        $("#dfDetail_chjernou").val(rwd_chjernoi())
    }
	return true;
}