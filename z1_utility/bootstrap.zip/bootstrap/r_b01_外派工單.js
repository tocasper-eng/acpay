var status_h
var status_d
//01 檔頭編輯狀態
function dfMaster_onLoad(row)
{
   status_h=$("#dfMaster").form('status')
}
//01 檔身編輯狀態
function dfDetail_onLoad(row)
{
   status_d=$("#dfDetail").form('status')
}

//02 檔頭存檔前
function dfMaster_onApply()
{
    if(status_h=="updated")
    {
        $("#DataPanel2_chjernou").val(rwd_chjernoi())
    }
   
    //筆數回寫檔頭
   // var rows = $('#dgDetail').datagrid('getRows'); 
    //$("#dfMaster_qtcnt").val(rows.length)
	return true;
}
//02 檔身存檔前
function dfDetail_onApply()
{
    if(status_d=="updated")
    {
        $("#dfDetail_chjernou").val(rwd_chjernoi())
    }
	return true;
}

//03 存檔後
function dfMaster_onApplied(data)
{
  rwd_reload()
}


function dfDetail_onApplied(data)
{
  // rwd_reload()
}





//04 過帳狀態旗標顏色 
function dgMaster_chjernop_formatter(value, row, index)
{
	return rwd_color_chjernop(value);
}
//05 核准狀態旗標顏色 
function dgMaster_chjernoz_formatter(value, row, index)
{
	return rwd_color_chjernoz(value);
}
//06 作廢狀態旗標顏色 
function dgMaster_chjernov_formatter(value, row, index)
{
	return rwd_color_chjernov(value);
}
//07 過帳
function ep_post()
{
    
   
    var sIndex = $("#dgMaster").datagrid("getSelectedIndex");
    if (sIndex >= 0) {
       rwd_post($("#dgMaster").datagrid("getRows")[sIndex].menuflag,$("#dgMaster").datagrid("getRows")[sIndex].chjernop) 
     }
    else {
      $.alert('請選擇一筆資料','info');
    }
  
}



//08 核准 
//function ep_codezy()
//{
//    var sIndex = $("#dgMaster").datagrid("getSelectedIndex");
//    if (sIndex >= 0) {
//        rwd_codezy($("#dgMaster").datagrid("getRows")[sIndex].menuflag,$("#dgMaster").datagrid("getRows")[sIndex].chjernoz) 
//    }
//    else {
//        $.alert('請選擇一筆資料','info');
//    }
//}
function ep_codezy() {
    try {
        // 获取数据表格中选中的行
        const selectedRow = $("#dgMaster").datagrid("getSelected");
        // 检查是否选中了数据
        if (!selectedRow) {
            $.alert('請選擇一筆資料', 'info');
            return false;
        }
        // 检查是否已经核准（检查 chjernoz 字段的第一个字符是否为 'Y'）
        if (selectedRow.chjernoz && selectedRow.chjernoz.toString().charAt(0).toUpperCase() === 'Y') {
            $.alert('已經核准，無需核准！', 'info');
            return false;
        }
        // 检查是否已经作废（检查 chjernov 字段的第一个字符是否为 'Y'）
        if (selectedRow.chjernov && selectedRow.chjernov.toString().charAt(0).toUpperCase() === 'Y') {
            $.alert('已經作廢，無需核准！', 'info');
            return false;
        }
        // 所有验证通过，可以执行核准操作
        // 这里可以添加核准的具体逻辑
        rwd_codezy(selectedRow.menuflag, selectedRow.chjernoz);
        return true;
    } catch (error) {
        // 错误处理
        console.error('Error in ep_codezy:', error);
        $.alert('處理資料時發生錯誤', 'error');
        return false;
    }
}
//09 取消
function ep_codezn()
{
    var sIndex = $("#dgMaster").datagrid("getSelectedIndex");
    if (sIndex >= 0) {
        rwd_codezn($("#dgMaster").datagrid("getRows")[sIndex].menuflag,$("#dgMaster").datagrid("getRows")[sIndex].chjernoz) 
    }
    else {
        $.alert('請選擇一筆資料','info');
    }
}
//10 作廢
function ep_void() {
    try {
        const selectedRow = $("#dgMaster").datagrid("getSelected");
        
        if (!selectedRow) {
            $.alert('請選擇一筆資料', 'info');
            return false;
        }
        
        // Check if already voided - using first character
        if (selectedRow.chjernov && selectedRow.chjernov.toString().charAt(0).toUpperCase() === 'Y') {
            $.alert('已作廢，不必再作廢！', 'info');
            return false;
        }
        
        // Check if approved - using first character
        if (selectedRow.chjernoz && selectedRow.chjernoz.toString().charAt(0).toUpperCase() === 'Y') {
            $.alert('已核准，請先取消核准，才能作廢！', 'info');
            return false;
        }
        
        // If all validations pass, proceed with void operation
        rwd_void(selectedRow.menuflag, selectedRow.chjernov, selectedRow.chjernoz);
        return true;
        
    } catch (error) {
        console.error('Error in ep_void:', error);
        $.alert('處理資料時發生錯誤', 'error');
        return false;
    }
}
//function ep_void()
//{
 //   if (chjernov=="Y")
 //   { $.altert('已作廢，不必再作廢！','info')
  //  return
  //  }
  //  if(chjernoiz=="Y")
  //  {
  //      $.alter('已核准，請先取消核准，才能作廢！','info')
  //      return
  //  }
  
//}


//11 核後與廢後不可刪除
function dgMaster_onDelete(row)
{
    if(!chkcode(row.chjernov,'作廢後不可刪除！')) return false 
    if(!chkcode(row.chjernoz,'核准後不可刪除！')) return false 
	return true;
}
//12 核後與廢後不可修改
function dgMaster_onUpdate(row)
{
   // if(!chkcode(row.chjernoz,'核准後不可修改！')) return false 
   // if(!chkcode(row.chjernov,'作廢後不可修改！')) return false 
	return true;

}

//13批次新增
//function openMove()
//{
 //  $('#dgDetail').clientmove('openMove');
//}

function DataPanel3_客服類別_onSelect(value)
{
   if(value!='1/ 契約客戶')
        $("#DataPanel1_契約編號").attr('disabled','disabled')
   else
        $("#DataPanel1_契約編號").removeAttr('disabled')
}
