function get_Parent()
{
    var rows = $('#dgMaster').datagrid('getRows');
    if(rows.length>0)
           return rows[0].menuid;
    else 
        return null;
}
