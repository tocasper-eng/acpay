var status_h
var status_d
function dfMaster_onLoad(row)
{
    status_h=$("#dfMaster").form('status')
  
}
function dfMaster_onApply()
{
    if(status_h=="updated")
    {
        $("#dfMaster_chjernou").val(rwd_chjernoi())
    }
    return true;
}

function DataForm1_onLoad(row)
{
 status_d=$("#DataForm1").form('status')
}

function DataForm1_onApply()
{
    if(status_d=="updated")
    {
        $("#DataForm1_chjernou").val(rwd_chjernoi())
    }
	return true;
}
