function dgMaster_相關連結_formatter(value, row, index)
{
	return "<a href='"+value+"' target='_blank'/>"+value+"</a>";
}
