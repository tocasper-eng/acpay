var status_h
var status_d
//01 檔頭編輯狀態
function dfMaster_onLoad(row)
{
   status_h=$("#dfMaster").form('status')
}
//01 檔身編輯狀態
function dfDetail_onLoad(row)
{
   status_d=$("#dfDetail").form('status')
}

//02 檔頭存檔前
function dfMaster_onApply()
{
    if(status_h=="updated")
    {
        $("#dfMaster_chjernou").val(rwd_chjernoi())
    }
   
    //筆數回寫檔頭
   // var rows = $('#dgDetail').datagrid('getRows'); 
    //$("#dfMaster_qtcnt").val(rows.length)
	return true;
}
//02 檔身存檔前
function dfDetail_onApply()
{
    if(status_d=="updated")
    {
        $("#dfDetail_chjernou").val(rwd_chjernoi())
    }
	return true;
}
