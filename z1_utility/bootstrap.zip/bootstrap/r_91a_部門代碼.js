var status_h
function dfMaster_onLoad(row)
{
    status_h=$("#dfMaster").form('status')
}
function dfMaster_onApply()
{
    if(status_h=="updated")
    {
        $("#dfMaster_chjernou").val(rwd_chjernoi())
    }
    return true;
}
