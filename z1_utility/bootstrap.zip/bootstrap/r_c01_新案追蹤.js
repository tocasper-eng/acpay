var status_h

//01 檔頭編輯狀態
function dfMaster_onLoad(row)
{
   status_h=$("#dfMaster").form('status')
}
//02 檔頭存檔前
function dfMaster_onApply()
{
    if(status_h=="updated")
    {
        $("#dfMaster_chjernou").val(rwd_chjernoi())
    }
   
   
	return true;
}
function dgMaster_onUpdate(row)
{
    if(row.flowflag.indexOf('Z')>=0)
    {
        $.alert("已經核准不能編輯",'info')
        return false
    }
	return true;
}

function dfMaster_onDelete(row)
{
     if(row.flowflag.indexOf('Z')>=0)
    {
        $.alert("已經核准不能刪除",'info')
        return false
    }
	return true;
}
