public string SET_PWD(dynamic objParam)
{   
    string id = objParam["你的參數名稱"]; //取得前端傳至後端的參數       
    string sql= "SELECT * FROM USERS WHERE ISNULL(PWD,'')=''"; //SQL條件句    
    DataTable Tmp = ExecuteDataTable("acpay", sql); //執行SQL，"ERPS"為執行的資料庫   
    for(int i=0;i<Tmp.Rows.Count;i++)
    {
        string password = new EncryptHelper().EncryptPassword(Tmp.Rows[i]["USERID"].ToString(), "acpay");
        string newpassword=password.Replace("'","''");
        string sql1= "UPDATE USERS SET PWD='"+newpassword+"' WHERE USERID='"+Tmp.Rows[i]["USERID"].ToString()+"'";            
        ExecuteNonQuery("acpay", sql1); //執行SQL，"ERPS"為執行的資料庫   
    }
    return "";
}
public string INSERT_USERS(dynamic objParam)
{   
     string sql= "insert into USERS(USERID,USERNAME) select emplnn,emplnm from eep_empl where emplnn not in (select USERID FROM USERS)";            
     ExecuteNonQuery("acpay", sql); //執行SQL，"ERPS"為執行的資料庫   
     return "";
}

//新增資訊
public string srv_chjernoi(dynamic param)
{
    string sql= "DECLARE @user NVARCHAR(30)='"+param.user+"' DECLARE @username NVARCHAR(30)='"+param.userName+"'  DECLARE @database NVARCHAR(30)='"+param.database+"'  DECLARE @solution NVARCHAR(30)='"+param.solution+"'   DECLARE @computer NVARCHAR(30)='"+param.computer+"'   DECLARE @sqlpass NVARCHAR(99) ;EXECUTE dbo.ep_eep_chjernoi @user,@username,@database,@solution,@computer,@sqlpass OUTPUT;SELECT @sqlpass as sqlpass";   
    DataTable Tmp = ExecuteDataTable("acpay", sql); //執行SQL，"EEPCore"為執行的資料庫   
    int count = Tmp.Rows.Count;
    string retval = "";
    if(count > 0){
        retval = Tmp.Rows[0]["sqlpass"].ToString();
    }
    return retval;
}
//post  
public string srv_post(dynamic param)
{
    try{
        string sql="exec ep_"+param.menuflag.ToString().Substring(0,3)+"_pt '"+param.menuflag+"','"+ param.sqlpass+"'";            
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}
//codezy  
public string srv_codezy(dynamic param)
{
    try{
        string sql="exec ep_"+param.menuflag.ToString().Substring(0,3)+"_zy '"+param.menuflag+"','"+ param.sqlpass+"'";        
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}
//codezn  
public string srv_codezn(dynamic param)
{
    try{
        string sql="exec ep_"+param.menuflag.ToString().Substring(0,3)+"_zn '"+param.menuflag+"','"+ param.sqlpass+"'";     
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}
//closey  
public string srv_closey(dynamic param)
{
    try{
        string sql="exec ep_"+param.menuflag.ToString().Substring(0,3)+"_closey '"+param.menuflag+"','"+ param.sqlpass+"'";        
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}
//codezn  
public string srv_closen(dynamic param)
{
     try{
        string sql="exec ep_"+param.menuflag.ToString().Substring(0,3)+"_closen '"+param.menuflag+"','"+ param.sqlpass+"'";        
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}

//void  
public string srv_void(dynamic param)
{
    try{
        string sql="exec ep_"+param.menuflag.ToString().Substring(0,3)+"_vy '"+param.menuflag+"','"+ param.sqlpass+"'";     
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}
//代理
public string  ep_91b_00(dynamic param) 
{
    try{
        string sql="exec ep_91b_00 ";
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}
public string  ep_92b_00(dynamic param) 
{
    try{
        string sql="exec ep_92b_00 ";          
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}
public string   ep_timer_eep_del(dynamic param) 
{
    try{
        string sql="exec ep_timer_eep_del ";          
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}
public string   ep_timer_post_del(dynamic param) 
{
    try{
        string sql="exec ep_timer_post_del ";          
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}
public string  ep_timer_void_del(dynamic param) 
{
    try{
        string sql="exec ep_timer_void_del ";          
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}
public string  ep_timer_codez_del(dynamic param) 
{
    try{
        string sql="exec ep_timer_codez_del ";          
        ExecuteNonQuery("acpay", sql); 
        //執行SQL，"ERPS"為執行的資料庫
        return "執行成功";
    }
    catch (Exception e){
        return "執行失敗";
    }
}
