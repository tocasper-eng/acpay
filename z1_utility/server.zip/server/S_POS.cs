public string AutoNumber1_onGetFixed(object sender, string fixedString, dynamic rows)
{
    /*string m="";
if(rows[0].契約狀態=="租賃")
m="P";
else
m="Q";
string 標的物地址=rows[0].標的物地址.ToString();
string zipcode= get_zip(標的物地址.Substring(0,2));
string 成約日期= rows[0].成約日期.ToString();
var dates=成約日期.Substring(2,2);
return m+dates+zipcode+fixedString;*/
    string sql = "SELECT .dbo.uf_契約編號('"+rows[0].契約狀態.ToString()+"','"+rows[0].標的物地址.ToString()+"') AS Result";
    var table = ExecuteDataTable("acpay", sql);
    string result = "";
    if (table.Rows.Count > 0)
    {
        result = table.Rows[0]["Result"]?.ToString();
    }
    return result+fixedString;
}
public string get_zip(string objParam)
{   
    string 標的物地址 = objParam; //取得前端傳至後端的參數       
    string sql= "select * from zip where zipname like N'%"+標的物地址+"%'"; //SQL條件句    
    DataTable Tmp = ExecuteDataTable("acpay", sql); //執行SQL，"ERPS"為執行的資料庫    
    string retval =Tmp.Rows[0]["zipcode"].ToString();
    return retval;
}
